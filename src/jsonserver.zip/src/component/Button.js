import React from 'react'

 function Button(props) {
    console.log("Button.js render olundu")
  return <button onClick={props.plusFunc}>Artir</button>;
}

export default React.memo(Button)