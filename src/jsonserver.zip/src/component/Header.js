import React from "react";

function Header() {
  return (
    <div>
      <h4>AA</h4>
    </div>
  );
}

export default React.memo(Header);
