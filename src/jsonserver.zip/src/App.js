import React, { useState, useEffect } from "react";
import Header from "./component/Header";
import axios from "axios";
import "./App.css";
import uniqid from "uniqid";




export default function App() {

 

  const [data, setData] = useState([]);
  const [user, setUser] = useState("");
  const [surname, setSurname] = useState("");

  const getData = () => {
    axios.get("http://localhost:3000/students").then((res) => {
      setData(res.data);
      setUser("");
      setSurname("");
    });
  };

  useEffect(() => {
  getData()
  }, []);

 


  const userGonder = () => {
    axios
      .post("http://localhost:3000/students", {
        name: user,
        surname: surname,
        id: Date.now()
      })
      .then((res) => {

      getData()



       
      });
  };

const deleteUser = (id)=>{

axios.delete(`http://localhost:3000/students/${id}`).then((res)=>{
    getData();
})

}

  return (
    <div>
      {data.length ? (
        data.map((e) => {
          return (
            <h3 key={e.id}>
              {e.name} {e.surname} --
              <i
                className="fa-solid fa-user-minus"
                onClick={() => deleteUser(e.id)}
              ></i>
            </h3>
          );
        })
      ) : (
        <h3>Siyahi bosdur</h3>
      )}

      <input
        type="text"
        placeholder="Ad yazin:"
        value={user}
        onChange={(e) => setUser(e.target.value)}
      />
      <input
        type="text"
        placeholder="Soyad yazin:"
        value={surname}
        onChange={(e) => setSurname(e.target.value)}
      />
      <button onClick={userGonder}>Gonder</button>
    </div>
  );
}
