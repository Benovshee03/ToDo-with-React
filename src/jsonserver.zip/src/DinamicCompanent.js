import React from 'react'
import { useParams } from 'react-router-dom'

export default function DinamicCompanent() {

    let data= useParams()
  return (
    <>
      {console.log(data)}
      <div>DinamicCompanent</div>
      <h2>{data.id}</h2>
    </>
  );
}
