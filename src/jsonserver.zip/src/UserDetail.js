import React, {useEffect,useState}  from 'react'
import { useParams } from 'react-router-dom'
import axios from 'axios'

export default function UserDetail() {
 
    const [userInformation,setUserInformation]=useState(null)
    
    let data = useParams()  // {id:5}
    var id = data.id


    useEffect(()=>{
axios.get(`https://jsonplaceholder.typicode.com/users/${id}`).then((response)=>{

setUserInformation(response.data)
console.log(response.data)
}).catch((err)=>{
    console.log(err)
})


    },[id])



  return (
    <>
      {userInformation && (
        <ul>
          <li>{userInformation.name}</li>
          <li>{userInformation.id}</li>
          <li>{userInformation.username}</li>
          <li>{userInformation.website}</li>
          <li>{userInformation.phone}</li>
          <li>{userInformation.email}</li>
        </ul>
      )}
    
    </>
  );
}
