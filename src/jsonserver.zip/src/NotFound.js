import React from 'react'

export default function NotFound() {
  return (
    <div>NotFound -- Bele bir sehife yoxdur</div>
  )
}
